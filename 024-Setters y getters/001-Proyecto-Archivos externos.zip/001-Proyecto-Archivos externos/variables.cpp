const std::string version = "0.1";
const std::string autor = "Jose Vicente Carratala";
int opcion;
std::vector<Contacto> base_de_datos;