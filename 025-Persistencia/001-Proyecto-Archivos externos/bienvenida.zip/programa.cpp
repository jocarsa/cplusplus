#include <iostream>
#include <vector>
#include "sqlite3.h"
#include "Contacto.cpp"
#include "variables.cpp"
#include "funciones.cpp"
#include "menu.cpp"
#define NOMBRE_PROGRAMA "Programa de gestión"
#include "bienvenida.cpp"


int main(){
    bienvenida();
    menu();
    return 0;
}